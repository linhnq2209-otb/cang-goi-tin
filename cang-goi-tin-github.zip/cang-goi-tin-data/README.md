# Dữ liệu Cảng Gói Tin (RIÊNG TƯ)

Kho này phải để **Private**. Không chứa họ tên, Gmail hay số điện thoại; học sinh chỉ được nhận ra bằng mã băm (16 kí tự, tính từ Gmail + chuỗi bí mật của trạm).

| Tệp | Nội dung |
| --- | --- |
| hocsinh.csv | ma_bam, lop, khoa (thầy điền dần nếu cần chia lớp) |
| chude.csv | danh mục chủ đề A–G |
| cauhoi.csv | thứ tự cố định của câu trong app, mức (Biết 1 · Hiểu 2 · Vận dụng 3) |
| tiendo/<ma_bam>.json | tiến độ của một học sinh: `cd` (tóm tắt theo chủ đề), `kq` (kết quả từng câu: 1 sai · 2 đúng lần 2 · 3 đúng ngay), `game` (trạng thái trò chơi). App ghi đè sau mỗi hoạt động |
| ketqua.csv | bảng gộp cho giáo viên, trạm tự sinh mỗi đêm |
| lichsu/ | bản chụp ketqua.csv cuối mỗi tháng |

Bậc theo chủ đề: điểm = 35·P (phủ) + 35·C (chính xác) + 20·R (chăm chỉ, số ngày luyện trong 28 ngày ÷ 12) + 10·V (tốc độ). SS ≥ 95 (phủ 100%, Vận dụng ≥ 90%) · S ≥ 88 (phủ ≥ 90%) · A ≥ 75 (phủ ≥ 80%) · B ≥ 60 · C ≥ 45 · D ≥ 30 · G Gà con (dưới 30 hoặc làm chưa đủ 5 câu).

Quy tắc: câu mới chỉ nối vào cuối danh sách của chủ đề; không đổi thứ tự câu cũ.
