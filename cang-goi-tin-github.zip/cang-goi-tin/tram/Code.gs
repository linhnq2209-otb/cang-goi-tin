/**
 * TRẠM ĐỒNG BỘ CẢNG GÓI TIN (Google Apps Script)
 * - Xác minh học sinh đăng nhập Google, tính mã băm (không lưu Gmail).
 * - Đọc / ghi đè tệp tiendo/<mã băm>.json trong kho GitHub riêng tư.
 * - Mỗi đêm gộp tất cả tiến độ thành ketqua.csv (có bậc SS, S, A, B, C, D, G).
 *
 * Cài đặt dự án (Project Settings → Script properties):
 *   GITHUB_TOKEN  token chỉ có quyền Contents (Read and write) trên kho dữ liệu
 *   REPO          ví dụ: linhnq2209-otb/cang-goi-tin-data
 *   CLIENT_ID     mã đăng nhập Google (OAuth Client ID) của trang GitHub Pages
 *   SECRET        một chuỗi ngẫu nhiên dài, giữ bí mật (đổi chuỗi = mọi mã băm đổi theo)
 */
const P = PropertiesService.getScriptProperties();

function doPost(e) {
  try {
    const b = JSON.parse(e.postData.contents);
    if (b.op === 'login') return out(login_(b.idToken));
    if (b.op === 'load') return out(load_(b.session));
    if (b.op === 'save') return out(save_(b.session, b.data));
    return out({ ok: false, err: 'op' });
  } catch (err) {
    return out({ ok: false, err: String(err.message || err).slice(0, 200) });
  }
}

function doGet() {
  return out({ ok: true, ten: 'Trạm Cảng Gói Tin', luc: new Date().toISOString() });
}

function out(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------- đăng nhập ---------- */
function login_(idToken) {
  if (!idToken) return { ok: false, err: 'token' };
  const res = UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(idToken), { muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) return { ok: false, err: 'token' };
  const t = JSON.parse(res.getContentText());
  if (t.aud !== P.getProperty('CLIENT_ID') || String(t.email_verified) !== 'true') return { ok: false, err: 'token' };
  const h = hash_(String(t.email).toLowerCase());
  const exp = Date.now() + 30 * 864e5; // phiên dùng 30 ngày
  const s = h + '.' + exp;
  return { ok: true, hash: h, session: s + '.' + sign_(s), data: readTiendo_(h) };
}

function hash_(email) {
  const d = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, P.getProperty('SECRET') + '|' + email, Utilities.Charset.UTF_8);
  return hex_(d).slice(0, 16);
}
function hex_(bytes) { return bytes.map(function (b) { return ('0' + (b & 255).toString(16)).slice(-2); }).join(''); }
function sign_(s) { return hex_(Utilities.computeHmacSha256Signature(s, P.getProperty('SECRET'))).slice(0, 32); }
function checkSession_(sess) {
  const p = String(sess || '').split('.');
  if (p.length !== 3) return null;
  if (sign_(p[0] + '.' + p[1]) !== p[2] || Number(p[1]) < Date.now()) return null;
  return p[0];
}

/* ---------- nạp / ghi ---------- */
function load_(sess) {
  const h = checkSession_(sess);
  if (!h) return { ok: false, err: 'session' };
  return { ok: true, data: readTiendo_(h) };
}

function save_(sess, data) {
  const h = checkSession_(sess);
  if (!h) return { ok: false, err: 'session' };
  if (!data || typeof data !== 'object') return { ok: false, err: 'data' };
  const txt = JSON.stringify(data);
  if (txt.length > 400000) return { ok: false, err: 'size' };
  const path = 'tiendo/' + h + '.json';
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const cur = gh_('GET', path);
    if (cur && cur.content) { // không cho bản cũ hơn đè bản mới hơn
      const old = decode_(cur.content);
      if (old && old.cap_nhat && data.cap_nhat && String(old.cap_nhat) > String(data.cap_nhat)) return { ok: true, giu: 'ban-moi-hon-tren-mang' };
    }
    const body = { message: 'tiendo ' + h, content: Utilities.base64Encode(txt, Utilities.Charset.UTF_8) };
    if (cur && cur.sha) body.sha = cur.sha;
    gh_('PUT', path, body);
    return { ok: true, cap_nhat: data.cap_nhat };
  } finally {
    lock.releaseLock();
  }
}

function readTiendo_(h) {
  const f = gh_('GET', 'tiendo/' + h + '.json');
  return f && f.content ? decode_(f.content) : null;
}
function decode_(b64) {
  return JSON.parse(Utilities.newBlob(Utilities.base64Decode(String(b64).replace(/\n/g, ''))).getDataAsString('UTF-8'));
}

function gh_(method, path, body) {
  const url = 'https://api.github.com/repos/' + P.getProperty('REPO') + '/contents/' + path;
  const o = {
    method: method.toLowerCase(), muteHttpExceptions: true,
    headers: { Authorization: 'Bearer ' + P.getProperty('GITHUB_TOKEN'), Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' }
  };
  if (body) { o.contentType = 'application/json'; o.payload = JSON.stringify(body); }
  const r = UrlFetchApp.fetch(url, o), c = r.getResponseCode();
  if (c === 404) return null;
  if (c >= 300) throw new Error('GitHub ' + c + ': ' + r.getContentText().slice(0, 160));
  return JSON.parse(r.getContentText());
}

/* ---------- gộp ketqua.csv (đặt trình kích hoạt chạy mỗi đêm) ---------- */
function gopKetQua() {
  const list = gh_('GET', 'tiendo') || [];
  const rows = [['ma_bam', 'ma_cd', 'so_cau', 'lam', 'dung', 'diem_dat', 'diem_toi_da', 'giay', 'ngay_luyen', 'P', 'C', 'R', 'V', 'diem', 'bac', 'cap_nhat']];
  list.forEach(function (f) {
    if (!/\.json$/.test(f.name)) return;
    const h = f.name.replace('.json', '');
    const d = readTiendo_(h);
    if (!d || !d.cd) return;
    Object.keys(d.cd).forEach(function (cd) {
      const s = d.cd[cd];
      rows.push([h, cd, s.so_cau, s.lam, s.dung, s.diem_dat, s.diem_toi_da, s.giay, s.ngay_luyen, s.P, s.C, s.R, s.V, s.diem, s.bac, d.cap_nhat]);
    });
  });
  const csv = rows.map(function (r) { return r.join(','); }).join('\n') + '\n';
  const cur = gh_('GET', 'ketqua.csv');
  const body = { message: 'gop ketqua ' + new Date().toISOString().slice(0, 10), content: Utilities.base64Encode(csv, Utilities.Charset.UTF_8) };
  if (cur && cur.sha) body.sha = cur.sha;
  gh_('PUT', 'ketqua.csv', body);
  // cuối tháng: chụp lại vào lichsu/
  const t = new Date(), mai = new Date(t.getTime() + 864e5);
  if (mai.getDate() === 1) {
    const p = 'lichsu/' + t.toISOString().slice(0, 7) + '.csv', old = gh_('GET', p);
    const b2 = { message: 'lichsu ' + p, content: body.content };
    if (old && old.sha) b2.sha = old.sha;
    gh_('PUT', p, b2);
  }
}

/* Chạy một lần bằng tay để kiểm tra cài đặt: xem nhật ký (Executions). */
function kiemTraCaiDat() {
  ['GITHUB_TOKEN', 'REPO', 'CLIENT_ID', 'SECRET'].forEach(function (k) { if (!P.getProperty(k)) throw new Error('Thiếu ' + k); });
  const r = gh_('GET', 'README.md');
  Logger.log(r ? 'Đọc được kho ' + P.getProperty('REPO') : 'Không thấy README.md trong kho');
}
